---
name: Kinetic Hardware & Sports Interface
colors:
  surface: '#121316'
  surface-dim: '#121316'
  surface-bright: '#38393c'
  surface-container-lowest: '#0d0e11'
  surface-container-low: '#1b1b1f'
  surface-container: '#1f1f23'
  surface-container-high: '#292a2d'
  surface-container-highest: '#343538'
  on-surface: '#e3e2e6'
  on-surface-variant: '#c9c8ab'
  inverse-surface: '#e3e2e6'
  inverse-on-surface: '#2f3034'
  outline: '#929278'
  outline-variant: '#474832'
  surface-tint: '#c6cf00'
  primary: '#ffffff'
  on-primary: '#303300'
  primary-container: '#e2ec00'
  on-primary-container: '#646900'
  inverse-primary: '#5e6300'
  secondary: '#fff3d2'
  on-secondary: '#3a3000'
  secondary-container: '#fdd400'
  on-secondary-container: '#6f5c00'
  tertiary: '#ffffff'
  on-tertiary: '#00354a'
  tertiary-container: '#c4e7ff'
  on-tertiary-container: '#006c93'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e2ec00'
  primary-fixed-dim: '#c6cf00'
  on-primary-fixed: '#1b1d00'
  on-primary-fixed-variant: '#474a00'
  secondary-fixed: '#ffe170'
  secondary-fixed-dim: '#e9c400'
  on-secondary-fixed: '#221b00'
  on-secondary-fixed-variant: '#544600'
  tertiary-fixed: '#c4e7ff'
  tertiary-fixed-dim: '#7bd0ff'
  on-tertiary-fixed: '#001e2c'
  on-tertiary-fixed-variant: '#004c69'
  background: '#121316'
  on-background: '#e3e2e6'
  surface-variant: '#343538'
  chassis-carbon: '#121316'
  surface-plate: '#1A1C20'
  surface-elevated: '#22252A'
  score-stop-red: '#EF4444'
  score-start-green: '#22C55E'
  hardware-border: '#334155'
  spec-slate: '#94A3B8'
typography:
  display-lg:
    fontFamily: Sora
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Sora
    fontSize: 34px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Sora
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Sora
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Sora
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
  headline-sm:
    fontFamily: Sora
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Work Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Work Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Work Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  spec-numeral-lg:
    fontFamily: JetBrains Mono
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 42px
    letterSpacing: -0.02em
  spec-code:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.04em
  label-pill:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system expresses high-performance industrial engineering, precision timing, and athletic command. Designed specifically for professional arena operators, sports facility directors, referees, and timekeepers, the interface mirrors the tactile confidence and high-visibility durability of physical scoring consoles.

The aesthetic blends **High-Contrast / Bold** sports telemetry with modern **Tactile Industrialism**:
- **Carbon-Dense Canvas:** Deep graphite and matte obsidian backdrops inspired by powder-coated console chassis, keeping arena eye fatigue minimal during nighttime or low-light sporting events.
- **Electric Telemetry Yellow:** Searing neon amber-yellow directly drawn from physical control keycaps, silkscreened board outlines, and official timing accents.
- **Instrument Precision:** Crisp technical typography, monospaced numerical readouts, and tactile hardware buttons with crisp outer concentric rings and illuminated states.

## Colors

The palette is engineered for extreme readability in demanding physical arena environments, utilizing high-contrast luminescent accents over deep structural darks.

- **Primary Accent (`#E6F000` / `#FFD600`):** Electric sporting neon yellow and amber gold. Used strictly for core interactive calls to action, active scorepad operational status, primary keycaps, and telemetry highlights.
- **Chassis Neutrals (`#121316`, `#1A1C20`, `#22252A`):** Industrial graphite surfaces representing the physical console shell, recessed bezel panels, and tactile card modules.
- **Technical & Signal Accents:**
  - `hardware-border` (`#334155`): Precise machined perimeter lines and modular dividers.
  - `spec-slate` (`#94A3B8`): Calibration metadata, hardware input labels, and auxiliary descriptions.
  - `score-stop-red` (`#EF4444`) & `score-start-green` (`#22C55E`): Standardized match clock controls, horn alerts, and active event indicators.

## Typography

The typographic hierarchy establishes clear technical communication:
- **Display & Headings (Sora):** Muscular, athletic geometric sans with sculpted angular joins that evoke hardware precision and sports dynamism.
- **Body & Editorial (Work Sans):** Highly legible, neutral workhorse engineered for maximum clarity across specifications, user manuals, and feature rundowns.
- **Telemetry & Technical Specs (JetBrains Mono):** Monospaced numeric tables, clock timers, hardware input channels (RS485, HDMI, USB, RF), and telemetry readouts. Numbers always render tabular with zero horizontal shifting during live value toggling.

## Layout & Spacing

The layout is built upon an 8pt modular grid that shifts into an optimized touch-first column architecture on mobile viewports.

- **Mobile (< 768px):** 4-column layout with 16px margins (`1rem`) and 12px gutters (`0.75rem`). Primary controls, specification grids, and feature badges maintain minimum touch targets of 48px to accommodate rapid arena operation.
- **Tablet & Desktop (>= 768px):** 8-column and 12-column layouts with 24px margins (`1.5rem`) and 16px gutters (`1rem`), allowing dual-column hardware feature teardowns and side-by-side technical specification sheets.
- **Rhythm:** Dense, modular telemetry sections separated by generous `space-xl` (`2.5rem`) macro dividers to ensure clear visual chunking between product overview, hardware ergonomics, and digital sport protocol listings.

## Elevation & Depth

Visual hierarchy leverages hardware chassis stratification with glowing luminescence instead of traditional drop shadows:

- **Level 0 (Chassis Foundation):** `#121316` flat carbon base.
- **Level 1 (Machined Plate Surface):** `#1A1C20` background with a subtle 1px border of `#334155` (low-contrast outline), mimicking the cut metal plate of the physical Scorepad console.
- **Level 2 (Tactile Control Blocks & Badges):** `#22252A` elevated module surfaces. Soft inner bevel: `inset 0 1px 0 rgba(255, 255, 255, 0.08)`.
- **Level 3 (Interactive Illumination):** High-priority operational triggers and active modes emit a high-contrast electric glow: `0 0 16px rgba(230, 240, 0, 0.35)` to recreate illuminated hardware push-buttons in dimmed sports halls.

## Shapes

The design language balances the molded ergonomics of handheld arena consoles with precision tech styling:
- **Cards & Enclosures:** `0.5rem` (`rounded-md`) up to `1rem` (`rounded-lg`) matching the physical rounded corners of the Scorepad chassis.
- **Badges & Hardware Tags:** Fully pill-shaped (`rounded-full`) for sport category tags (FIBA, EHF, Multi-sport) and connection protocols.
- **Keycap Buttons:** Tactile circular geometry (`border-radius: 9999px`) echoing the iconic hardware push-buttons (Start, Stop, Horn, Reset) with concentric double borders.

## Components

### Hardware Action Buttons
- **Primary Hardware Keycap:** Inspired by the yellow START/STOP physical console switches. Rendered as a bold circular or pill button with `#E6F000` background, `#121316` bold text, a distinct 2px outer gap ring (`ring-2 ring-offset-2 ring-[#E6F000]`), and high-contrast haptic press states.
- **Secondary Outlined Button:** `#1A1C20` base, 1.5px solid `#334155` outline, hover transition to `#E6F000` border and text.

### Specification & Spec-Sheets
- **Hardware Spec Metric Cards:** Deep obsidian `#1A1C20` background, top border highlight with a 1px neon line accent, large tabular numerals in `JetBrains Mono`, and technical metric units labeled in `spec-slate` uppercase.
- **Protocol Badges:** Pill-shaped indicators featuring small neon dot indicators (e.g., green dot for `ACTIVE DMX`, amber dot for `WIRELESS 868MHz`).

### Modular Product Cards
- **Feature Showcase:** Dark graphite cards with low-contrast borders (`#334155`), integrated screenshot or hardware viewport, high-contrast headline, and mono-tagged dimension/compatibility chips.

### Interactive Controls (Form Elements)
- **Toggles & Segmented Controls:** Recessed hardware track (`#121316`) with an elevated tactile thumb (`#E6F000` or `#FFFFFF`).
- **Inputs & Dropdowns:** Solid `#1A1C20` fill, 1px `#334155` border, focusing to a crisp `#FFD600` perimeter outline with 0-blur.