---
name: ScoreTech Engineering
colors:
  surface: '#f9f9ff'
  surface-dim: '#cfdaf2'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eeff'
  surface-container-high: '#dee8ff'
  surface-container-highest: '#d8e3fb'
  on-surface: '#111c2d'
  on-surface-variant: '#434655'
  inverse-surface: '#263143'
  inverse-on-surface: '#ecf1ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#575f6e'
  on-secondary: '#ffffff'
  secondary-container: '#d8e0f2'
  on-secondary-container: '#5b6373'
  tertiary: '#784b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#996100'
  on-tertiary-container: '#ffeedd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#dbe2f5'
  secondary-fixed-dim: '#bfc6d9'
  on-secondary-fixed: '#141c29'
  on-secondary-fixed-variant: '#3f4756'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f9f9ff'
  on-background: '#111c2d'
  surface-variant: '#d8e3fb'
typography:
  headline-xl:
    fontFamily: Barlow Condensed
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 60px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Barlow Condensed
    fontSize: 38px
    fontWeight: '700'
    lineHeight: 42px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Barlow Condensed
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Barlow Condensed
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: 0em
  headline-md:
    fontFamily: Barlow Condensed
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: 0em
  headline-sm:
    fontFamily: Barlow Condensed
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.04em
  label-md:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  gutter-lg: 2rem
  margin: 2rem
  margin-mobile: 1rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes a high-performance B2B engineering aesthetic tailored for sports facility directors, municipal civil engineers, architectural specifiers, and school district procurement officers. The visual character merges structural industrial solidity with the high-visibility precision of athletic timing and scoring hardware.

The design movement combines **Corporate Modern** with **Technical Precision Engineering**:
- Structural layouts relying on calibrated lines, micro-data displays, and hardware-grade visual containers.
- High-contrast readability reminiscent of LED matrix digital scoreboards, stadium lighting, and technical CAD architectural plans.
- Utilitarian confidence that avoids consumer flashiness in favor of rugged reliability, clear installation schematics, and rigorous institutional trust.
- Controlled use of digital amber LEDs against deep stadium navy surfaces to evoke stadium control rooms, court-side consoles, and real-time field hardware.

## Colors

The palette directly references the operating environments of athletic infrastructure: dark indoor arena ceilings, exterior stadium floodlights, crisp boundary lines, and luminous scoreboard diodes.

### Primary Role (Electric Cobalt — `#2563EB`)
Serves as the high-impact operational color. Used for primary conversion triggers (RFP requests, spec sheet downloads, interactive quotation steps), focused input states, and active hardware statuses.

### Secondary Role (Arena Navy — `#0B1320`)
The grounding structural tone. Used for dominant technical footers, inverted hero modules, specification header bars, and high-contrast dark callouts that replicate stadium display housings.

### Tertiary Role (Digital LED Amber — `#F59E0B`)
An emissive accent inspired by 7-segment and dot-matrix LED score displays. Reserved strictly for vital metrics, warranty and certification indicators (e.g., FIBA / FIFA / NFHS compliance), attention-demanding hardware statuses, and secondary highlight badges.

### Neutral System (Slate Charcoal & Surface Light)
- **Primary Charcoal Neutral (`#1E293B`):** Body typography, technical dimension markings, and secondary hardware structural elements.
- **Surface Foundations:** Crisp white (`#FFFFFF`) for base documentation and data sheets, slate white (`#F8FAFC`) for page canvases, and muted slate (`#F1F5F9`) for mechanical card backgrounds, table row alternate striping, and containment borders (`#E2E8F0`).

## Typography

The typographic hierarchy communicates industrial performance and technical clarity through a tripartite font allocation:

1. **Display & Headlines (`Barlow Condensed`):** Channeling stadium score displays, industrial equipment plaques, and architectural spec covers. The condensed verticality commands attention while conserving horizontal layout space for multi-column equipment tables. Always pair with tight line heights and uppercase treatments on section identifiers.
2. **Body Copy (`Inter`):** Engineered for dense spec manuals, procurement terms, regulatory texts, and operational overviews. It delivers objective clarity across varied screen calibrations.
3. **Data, Labels, and Metrics (`Space Grotesk`):** Injects a controlled digital-instrumentation aesthetic for technical specs (voltage, viewing distance, IP weather ratings, pixel pitch, lux output). Always rendered with open tracking to maximize scan-readability under bright or low-contrast conditions.

## Layout & Spacing

The layout is built on a 12-column engineering grid with structural boundaries and visible anchor points.

- **Desktop (1200px+):** 12-column grid, `margin-desktop` (3rem), `gutter` (1.5rem). Modules follow modular DIN paper ratios (1:1.414) for technical specs, product blueprints, and configuration calculators.
- **Tablet (768px - 1199px):** 8-column grid, `margin` (2rem), `gutter-sm` (1rem). Dual-column data structures reflow cleanly into technical vertical accordions.
- **Mobile (<768px):** 4-column grid, `margin-mobile` (1rem), `gutter-sm` (1rem). Product schematics switch to scrollable horizontal strip matrices with persistent dimension indicators.

Rhythm is strictly mathematical, built on multiples of 4px and 8px base units. Card groupings, data arrays, and specification matrices utilize compact component gaps (`space-xs` to `space-md`) to mirror physical rack-mounted consoles and hardware enclosures.

## Elevation & Depth

To emphasize structural durability, this system rejects heavy ambient blurs and float-heavy drop shadows. Visual depth is established through **Low-Contrast Outlines**, **Tonal Layering**, and **Mechanical Offset Surfaces**:

- **Hardware Framing:** Primary cards, equipment viewports, and spec modules use 1px solid borders in `#E2E8F0` on light canvases, and `#334155` on Arena Navy surfaces.
- **Tonal Stepping:** Rather than casting elevation shadows, surfaces elevate by stepping through canvas tints:
  - Base: `#F8FAFC`
  - Container: `#FFFFFF`
  - Inset/Nested Spec Box: `#F1F5F9`
- **Active & Interactive Elevation:** Interactive cards on hover introduce a subtle directional offset (1px vertical translation) anchored by a clean, crisp 1px border shift to Cobalt `#2563EB` and a short, dense anchor shadow: `0 4px 0 0 #0B1320` (or `0 4px 12px -2px rgba(11, 19, 32, 0.12)`).
- **LED Display Portals:** Scoreboard simulators and technical diagrams utilize an inverted Arena Navy (`#0B1320`) recessed background with a 1px inner stroke (`inset 0 0 0 1px #1E293B`) to replicate an integrated bezel.

## Shapes

The shape system adopts a **Soft Industrial Geometry** (`roundedness: 1`). 

- Default elements (input fields, action buttons, hardware spec modules, certification tags) feature a tight `0.25rem` (4px) radius.
- Large equipment enclosures, modular section wrappers, and facility gallery viewports employ `rounded-lg` at `0.5rem` (8px).
- Pill shapes and circular radius values are prohibited except for miniature circular LED status dots (e.g., active signal or power indicator).
- The compact corner radii communicate precision CNC machining, structural steel enclosure housings, and rigid electronic display bezels.

## Components

### Buttons
- **Primary (Conversion / Tender Spec):** Electric Cobalt (`#2563EB`) solid fill, pure white uppercase `Space Grotesk` typography, 4px corner radius, padding `0.75rem 1.5rem`. Hover triggers a dark cobalt shift (`#1D4ED8`) with zero radius morphing.
- **Secondary (Technical CAD / Spec Sheets):** 1px outline in `#0B1320` with clear text; fills with `#0B1320` on hover with white text.
- **Tertiary (Consultation / Hotline):** Transparent base, `#2563EB` link text with an integrated right arrow glyph (`→`) and bottom border accent.

### Chips & Compliance Badges
- Used for standards certification (e.g., "FIBA LEVEL 1", "EN 12966", "IP65 ALL-WEATHER", "IK10 IMPACT RESISTANT").
- Background: Surface Slate `#F1F5F9`, border 1px solid `#CBD5E1`, text in `#0B1320`, font `Space Grotesk` (`label-sm`).
- When highlighting mission-critical features, apply LED Amber background `#FEF3C7` with a `#F59E0B` border and `#92400E` text.

### Specification Cards & Blueprints
- Structured cards with a 24px top header band in `#0B1320` containing product line identifiers, followed by a `#FFFFFF` body displaying technical parameters in alternating zebra rows (`#FFFFFF` / `#F8FAFC`).
- Grid lines inside cards are strictly `#E2E8F0` at 1px width.

### Form Inputs & Quotation Selectors
- Background: `#FFFFFF`, border: 1.5px solid `#CBD5E1`, radius: 4px.
- Labels: Placed above fields in `Space Grotesk` (`label-md`), `#1E293B` neutral, featuring technical unit labels (e.g., `[mm]`, `[V]`, `[cd/m²]`) right-aligned in `#64748B`.
- Focus state: Border transitions to `#2563EB` with a crisp outer focus ring (`0 0 0 3px rgba(37, 99, 235, 0.15)`).

### Checkboxes & Segmented Selectors
- Square 16px checkboxes with a 2px radius and 1.5px solid border in `#0B1320`. Checked state fills `#2563EB` with a sharp white checkmark.
- Segmented unit switches (e.g., `METRIC / IMPERIAL` or `INDOOR / OUTDOOR` toggles) use a machine-tooled rectangular slate container (`#F1F5F9`) with an active solid white button tile.

### Municipal & Institutional Trust Units
- Modular horizontal bars designed for school district seals, federation credentials, and city partner logos. Displayed in monochrome `#64748B` with a hover transition to full brand contrast.